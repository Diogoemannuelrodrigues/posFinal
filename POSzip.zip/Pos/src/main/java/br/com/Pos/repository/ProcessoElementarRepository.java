package br.com.Pos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.Pos.entidade.ProcessoElementar;

public interface ProcessoElementarRepository extends JpaRepository<ProcessoElementar, Integer>{

}
